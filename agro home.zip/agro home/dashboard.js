document.addEventListener("DOMContentLoaded", () => {
    // 1. Define UI Components as variables
    const Brand = `
        <div class="nav-left">
            <button id="toggle-btn"><i class='bx bx-menu'></i></button>
            <div class="brand">AGRO<span>FARM</span></div>
        </div>`;

    const UserProfile = (id, status) => `
        <div class="nav-right">
            <div class="user-profile">
                <div class="user-details">
                    <span class="user-id">Worker: ${id}</span>
                    <span class="user-status">${status}</span>
                </div>
                <i class='bx bxs-user-circle profile-icon'></i>
            </div>
        </div>`;

    const SidebarLinks = [
        { href: 'overview.html', icon: 'bx bxs-dashboard', label: 'Overview', active: true },
        { href: 'area.html', icon: 'bx bxs-map-alt', label: 'Areas' },
        { href: 'sensors.html', icon: 'bx bxs-microchip', label: 'Sensors' },
        { href: 'controls.html', icon: 'bx bxs-slider-alt', label: 'Controls' }
    ].map(link => `
        <li>
            <a href="${link.href}" target="content-frame" class="${link.active ? 'active' : ''}">
                <i class='${link.icon}'></i> <span>${link.label}</span>
            </a>
        </li>`).join('');

    // 2. Assemble the Layout
    document.body.innerHTML = `
        <header class="top-bar">
            ${Brand}
            ${UserProfile('AF-2024', 'Online')}
        </header>

        <div class="dashboard-wrapper">
            <aside id="sidebar" class="sidebar">
                <ul class="nav-links">
                    ${SidebarLinks}
                </ul>
                <div class="sidebar-footer">
                    <a href="login.html"><i class='bx bx-log-out'></i> <span>Sign Out</span></a>
                </div>
            </aside>

            <main class="main-content">
                <iframe src="overview.html" name="content-frame" id="dash-iframe"></iframe>
            </main>
        </div>`;

    // 3. Logic (Wait until after innerHTML is set to grab elements)
    const toggleBtn = document.getElementById('toggle-btn');
    const sidebar = document.getElementById('sidebar');

    toggleBtn.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
    });
});